create database QLSINHVIEN

if OBJECT_ID('lop') is not null
drop table lop
go
create table lop
(
malop nvarchar(50) not null,
tenlop nvarchar(50) null,
constraint pk_lop primary key(malop)
)

if OBJECT_ID('mon') is not null
drop table mon
go
create table mon
(
mamon nvarchar(50) not null,
tenmon nvarchar(50) null,
constraint pk_mon primary key (mamon)
)

if OBJECT_ID('dssv') is not null
drop table dssv
go
create table dssv
(
masv nvarchar(50) not null,
tensv nvarchar(50) null,
malop nvarchar(50) null,
sdt nvarchar(15) null,
email nvarchar(50) null,
diachi nvarchar(50) null,
constraint pk_dssv primary key(masv),
constraint fk_dssv_lop foreign key(malop)
references lop
)

if OBJECT_ID('diem') is not null
drop table diem
go
create table diem
(masv nvarchar(50) not null,
mamon nvarchar(50) not null,
diem int null,
constraint pk_diem primary key(masv),
constraint fk_mon_diem foreign key (mamon)
references mon,
constraint fk_diem_dssv foreign key(masv)
references dssv
)

if OBJECT_ID('lichhoc') is not null
drop table lichhoc
go
create table lichhoc
(
malop nvarchar(50) not null,
mamon nvarchar(50) not null,
thoigian datetime null,
phonghoc nvarchar(10) null,
constraint pk_lichhoc primary key(malop),
constraint fk_lop_lichhoc foreign key(malop)
references lop,
constraint fk_mon_lichhoc foreign key(mamon)
references mon
)

if OBJECT_ID('lichsuhoc') is not null
drop database lichsuhoc
go
create table lichsuhoc
(
masv nvarchar(50) not null,
mamon nvarchar(50) not null,
trangthai bit null,
constraint pk_lichsuhoc primary key(masv),
constraint fk_dssv_lichsuhoc foreign key(masv)
references dssv,
constraint fk_mon_lichsuhoc foreign key(mamon)
references mon
)